import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import BASE_URL from "../../../../config/config";
import "../../cuentas_corrientes.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faXmark,
  faPlus,
  faPenToSquare,
  faTrashCan,
  faFloppyDisk,
  faArrowRotateRight,
  faUsers,
  faUser,
  faUserSlash,
  faUserCheck,
  faMagnifyingGlass,
  faIdCard,
  faFileInvoiceDollar,
  faCircleCheck,
} from "@fortawesome/free-solid-svg-icons";
import ModalEliminar from "../../../Global/Modales/ModalEliminar";
import "../../../Global/Global_css/Global_oscuro.css";

const API_URL = `${String(BASE_URL || "").replace(/\/+$/, "")}/api.php`;

function isTemaOscuro() {
  return (
    document.documentElement.getAttribute("data-theme") === "oscuro" ||
    document.body?.classList?.contains("dark")
  );
}

function buildHeadersGET() {
  const sessionKey = (localStorage.getItem("session_key") || "").trim();
  const token = (localStorage.getItem("token") || "").trim();
  const h = {};
  if (sessionKey) h["X-Session"] = sessionKey;
  if (token) h["Authorization"] = `Bearer ${token}`;
  return h;
}

function buildHeadersJSON() {
  return { ...buildHeadersGET(), "Content-Type": "application/json" };
}

function toUpperValue(value) {
  return String(value || "").toUpperCase();
}

function safeStr(value) {
  return String(value ?? "").trim();
}

function onlyDigits(value) {
  return String(value ?? "").replace(/\D/g, "");
}

function getClienteId(row) {
  return Number(row?.id_cliente ?? row?.id ?? 0);
}

function getClienteFiscalId(row) {
  return Number(row?.id_cliente_fiscal ?? row?.cliente_fiscal?.id_cliente_fiscal ?? 0);
}

function normalizeSearch(value) {
  return String(value ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim();
}

function normalizeFiscalData(data) {
  const src = data && typeof data === "object" ? data : {};
  const cuit = onlyDigits(src.fiscal_cuit || src.cuit || src.doc_nro || src.CUIT || "");
  const razonSocial = safeStr(
    src.razon_social ||
      src.razonSocial ||
      src.nombre ||
      src.apellidoNombre ||
      src.denominacion ||
      ""
  );
  const condicionIva = safeStr(src.condicion_iva || src.cond_iva || src.iva || src.descripcionImpuesto || "");
  const domicilio = safeStr(src.domicilio || src.direccion || src.domicilioFiscal || "");

  return {
    id_cliente_fiscal: Number(src.id_cliente_fiscal || 0) || null,
    id_cliente: Number(src.id_cliente || 0) || null,
    doc_tipo: Number(src.doc_tipo || 80) || 80,
    doc_nro: safeStr(src.doc_nro || cuit),
    cuit,
    razon_social: razonSocial,
    condicion_iva: condicionIva,
    domicilio,
    origen: safeStr(src.origen || "arca_cuit"),
    activo: Number(src.activo ?? 1) === 0 ? 0 : 1,
  };
}

function fiscalFromClienteRow(row) {
  if (!row || typeof row !== "object") return null;
  const nested = row.cliente_fiscal || row.fiscal || null;
  const fiscal = normalizeFiscalData(nested || row);
  if (!fiscal.cuit && !fiscal.razon_social && !fiscal.id_cliente_fiscal) return null;
  fiscal.id_cliente = fiscal.id_cliente || getClienteId(row) || null;
  return fiscal;
}

function fiscalIsUsable(fiscal) {
  const f = normalizeFiscalData(fiscal);
  return f.cuit.length === 11 && !!f.razon_social;
}

function fiscalHasAnyData(fiscal) {
  const f = normalizeFiscalData(fiscal);
  return !!(
    f.id_cliente_fiscal ||
    f.cuit ||
    f.razon_social ||
    f.condicion_iva ||
    f.domicilio
  );
}

function buildEmptyForm(activo = 1) {
  return {
    nombre: "",
    activo,
    cuit: "",
    fiscalData: null,
    fiscalError: "",
    fiscalLoading: false,
    fiscalConsultado: false,
    cargaManual: true,
  };
}

async function parseJsonOrThrow(res) {
  if (res.status === 401 || res.status === 403) {
    throw new Error("Sesión vencida o no autorizada. Volvé a iniciar sesión.");
  }

  const text = await res.text();
  if (!text) throw new Error("Respuesta vacía del servidor.");

  try {
    const data = JSON.parse(text);
    if (!res.ok || data?.exito === false) {
      throw new Error(data?.mensaje || `Error HTTP ${res.status}`);
    }
    return data;
  } catch (e) {
    if (
      e instanceof Error &&
      e.message &&
      !e.message.startsWith("Unexpected token")
    ) {
      throw e;
    }

    const preview = text.length > 400 ? `${text.slice(0, 400)}...` : text;

    throw new Error(
      text.startsWith("<!DOCTYPE") || text.startsWith("<")
        ? "La API devolvió HTML en vez de JSON. Revisá la ruta del backend."
        : `Respuesta inválida del servidor. HTTP ${res.status}\n${preview}`
    );
  }
}

async function apiGet(url) {
  const res = await fetch(url, {
    method: "GET",
    headers: buildHeadersGET(),
  });
  return parseJsonOrThrow(res);
}

async function apiPost(action, body) {
  const res = await fetch(`${API_URL}?action=${encodeURIComponent(action)}`, {
    method: "POST",
    headers: buildHeadersJSON(),
    body: JSON.stringify(body || {}),
  });
  return parseJsonOrThrow(res);
}

function FiscalResumen({ fiscal }) {
  const f = normalizeFiscalData(fiscal);
  if (!fiscalIsUsable(f) && !f.id_cliente_fiscal) return null;

  return (
    <div
      style={{
        border: "1px solid rgba(34, 197, 94, 0.25)",
        background: "rgba(34, 197, 94, 0.08)",
        borderRadius: 12,
        padding: "10px 12px",
        marginTop: -2,
        fontSize: 12,
        color: "var(--nv-text)",
        display: "grid",
        gap: 6,
      }}
    >
      <div style={{ fontWeight: 800, display: "flex", alignItems: "center", gap: 7 }}>
        <FontAwesomeIcon icon={faCircleCheck} /> Datos fiscales cargados
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "6px 10px" }}>
        <div>
          <b>CUIT:</b> {f.cuit || "—"}
        </div>
        <div>
          <b>IVA:</b> {f.condicion_iva || "—"}
        </div>
        <div style={{ gridColumn: "1 / -1" }}>
          <b>Razón social:</b> {f.razon_social || "—"}
        </div>
        <div style={{ gridColumn: "1 / -1" }}>
          <b>Domicilio:</b> {f.domicilio || "—"}
        </div>
      </div>
    </div>
  );
}

function FiscalEditableFields({ fiscal, cuit, saving, fiscalLoading, dark, onFieldChange }) {
  const f = normalizeFiscalData({ ...(fiscal || {}), cuit: fiscal?.cuit || cuit });
  if (!fiscalHasAnyData(f)) return null;

  return (
    <div
      style={{
        border: "1px solid rgba(15, 23, 42, 0.12)",
        background: dark ? "rgba(15, 23, 42, 0.30)" : "rgba(248, 250, 252, 0.88)",
        borderRadius: 14,
        padding: "12px",
        display: "grid",
        gap: 10,
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 8, fontWeight: 800, color: "var(--nv-text)", fontSize: 13 }}>
        <FontAwesomeIcon icon={faFileInvoiceDollar} />
        Datos legales editables
      </div>

      <div style={{ fontSize: 12, color: "var(--nv-muted)", lineHeight: 1.45 }}>
        Estos datos salen en facturación. Podés corregir domicilio, condición IVA o razón social si ARCA vino incompleto/desactualizado.
      </div>

      <div className="fl-field">
        <input
          type="text"
          className="fl-input"
          placeholder=" "
          value={f.razon_social}
          onChange={(e) => onFieldChange("razon_social", e.target.value)}
          disabled={saving || fiscalLoading}
        />
        <label className="fl-label">Razón social legal *</label>
      </div>

      <div className="fl-field">
        <input
          type="text"
          className="fl-input"
          placeholder=" "
          value={f.condicion_iva}
          onChange={(e) => onFieldChange("condicion_iva", e.target.value)}
          disabled={saving || fiscalLoading}
        />
        <label className="fl-label">Condición IVA</label>
      </div>

      <div className="fl-field">
        <textarea
          className="fl-input"
          placeholder=" "
          value={f.domicilio}
          onChange={(e) => onFieldChange("domicilio", e.target.value)}
          disabled={saving || fiscalLoading}
          rows={3}
          style={{ minHeight: 76, resize: "vertical", paddingTop: 14 }}
        />
        <label className="fl-label">Domicilio fiscal</label>
      </div>
    </div>
  );
}

function ModalDatosLegalesCliente({ open, dark, row, fiscal, loading, onClose, onEdit }) {
  if (!open) return null;

  const f = normalizeFiscalData(fiscal || fiscalFromClienteRow(row) || {});
  const tieneDatos = fiscalHasAnyData(f);

  return createPortal(
    <div className={["mi-modal__overlay", dark ? "mi-modal__overlay--dark" : ""].join(" ").trim()}>
      <div
        className={["mi-mini__modal", dark ? "mi-modal--dark" : ""].join(" ").trim()}
        role="dialog"
        aria-modal="true"
        onMouseDown={(e) => e.stopPropagation()}
        style={{ maxWidth: 560, width: "calc(100vw - 34px)" }}
      >
        <div className="mi-mini__head">
          <h4 className="mi-mini__title">Datos legales del cliente</h4>
          <button type="button" className="mi-mini__close" onClick={onClose} disabled={loading} aria-label="Cerrar">
            ✕
          </button>
        </div>

        <div className="mi-mini__body" style={{ display: "grid", gap: 12 }}>
          <div
            style={{
              border: "1px solid rgba(59, 130, 246, 0.22)",
              background: "rgba(59, 130, 246, 0.08)",
              borderRadius: 12,
              padding: "10px 12px",
              fontSize: 12,
              lineHeight: 1.45,
              color: "var(--nv-text)",
            }}
          >
            Cliente: <b>{row?.nombre || "—"}</b>
          </div>

          {loading ? (
            <div className="cc-loading-state" style={{ minHeight: 110 }}>
              <FontAwesomeIcon icon={faArrowRotateRight} spin />
              <span>Cargando datos legales...</span>
            </div>
          ) : tieneDatos ? (
            <div
              style={{
                border: "1px solid rgba(15, 23, 42, 0.12)",
                borderRadius: 12,
                overflow: "hidden",
              }}
            >
              {[
                ["CUIT", f.cuit || "—"],
                ["Razón social", f.razon_social || "—"],
                ["Condición IVA", f.condicion_iva || "—"],
                ["Domicilio fiscal", f.domicilio || "—"],
                ["Origen", f.origen || "—"],
              ].map(([label, value]) => (
                <div
                  key={label}
                  style={{
                    display: "grid",
                    gridTemplateColumns: "140px 1fr",
                    gap: 10,
                    padding: "10px 12px",
                    borderBottom: "1px solid rgba(15, 23, 42, 0.08)",
                    fontSize: 13,
                  }}
                >
                  <b style={{ color: "var(--nv-muted)" }}>{label}</b>
                  <span style={{ color: "var(--nv-text)", whiteSpace: "pre-wrap" }}>{value}</span>
                </div>
              ))}
            </div>
          ) : (
            <div
              style={{
                border: "1px solid rgba(245, 158, 11, 0.28)",
                background: "rgba(245, 158, 11, 0.10)",
                borderRadius: 12,
                padding: "12px",
                fontSize: 13,
                color: "var(--nv-text)",
                lineHeight: 1.45,
              }}
            >
              Este cliente todavía no tiene datos fiscales cargados. Podés editarlo y consultar ARCA por CUIT para crear los datos legales.
            </div>
          )}

          <div className="mi-mini__actions">
            <button type="button" className="mit-btn mit-btn--ghost" onClick={onClose} disabled={loading}>
              Cerrar
            </button>
            <button type="button" className="mit-btn mit-btn--solid" onClick={onEdit} disabled={loading}>
              {tieneDatos ? "Editar datos legales" : "Cargar datos legales"}
            </button>
          </div>
        </div>
      </div>
    </div>,
    document.body
  );
}

export default function ModalClientes({
  open,
  onClose,
  onActualizado,
  onToast,
}) {
  const closeBtnRef = useRef(null);

  const [dark, setDark] = useState(isTemaOscuro);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [accionandoId, setAccionandoId] = useState(null);
  const [clientes, setClientes] = useState([]);
  const [busqueda, setBusqueda] = useState("");
  const [pestana, setPestana] = useState("activos");
  const [modo, setModo] = useState("crear");
  const [editandoId, setEditandoId] = useState(null);
  const [form, setForm] = useState(() => buildEmptyForm(1));

  const [modalAccion, setModalAccion] = useState({
    open: false,
    type: null,
    row: null,
    loading: false,
  });

  const [modalFiscal, setModalFiscal] = useState({
    open: false,
    row: null,
    fiscal: null,
    loading: false,
  });

  const isBusy =
    loading ||
    saving ||
    form.fiscalLoading ||
    modalAccion.loading ||
    modalAccion.open ||
    modalFiscal.loading ||
    modalFiscal.open;

  useEffect(() => {
    const update = () => setDark(isTemaOscuro());

    const o1 = new MutationObserver(update);
    o1.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["data-theme"],
    });

    const o2 = new MutationObserver(update);
    if (document.body) {
      o2.observe(document.body, {
        attributes: true,
        attributeFilter: ["class"],
      });
    }

    return () => {
      o1.disconnect();
      o2.disconnect();
    };
  }, []);

  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, [open]);

  useEffect(() => {
    if (!open) return;

    const h = (e) => {
      if (e.key !== "Escape") return;
      if (modalAccion.open || modalFiscal.open) return;

      if (!loading && !saving && !form.fiscalLoading) {
        onClose?.();
      }
    };

    document.addEventListener("keydown", h, true);
    return () => document.removeEventListener("keydown", h, true);
  }, [open, onClose, loading, saving, form.fiscalLoading, modalAccion.open, modalFiscal.open]);

  useEffect(() => {
    if (open) {
      setTimeout(() => closeBtnRef.current?.focus(), 0);
      setBusqueda("");
      setModalFiscal({ open: false, row: null, fiscal: null, loading: false });
    }
  }, [open]);

  const resetForm = useCallback(() => {
    setModo("crear");
    setEditandoId(null);
    setForm(buildEmptyForm(pestana === "inactivos" ? 0 : 1));
  }, [pestana]);

  const cargarClientes = useCallback(
    async (tabActual = pestana) => {
      setLoading(true);
      try {
        const params = new URLSearchParams({
          action: "cc_clientes_listar",
          activo: tabActual === "inactivos" ? "0" : "1",
        });

        const data = await apiGet(`${API_URL}?${params.toString()}`);
        setClientes(Array.isArray(data?.clientes) ? data.clientes : []);
      } catch (err) {
        onToast?.("error", err?.message || "No se pudieron cargar los clientes.");
      } finally {
        setLoading(false);
      }
    },
    [onToast, pestana]
  );

  const cargarFiscalCliente = useCallback(async (idCliente) => {
    const id = Number(idCliente || 0);
    if (!id) return null;

    try {
      const params = new URLSearchParams({
        action: "cc_cliente_fiscal_get",
        id_cliente: String(id),
      });
      const data = await apiGet(`${API_URL}?${params.toString()}`);
      const fiscal = data?.cliente_fiscal ? normalizeFiscalData(data.cliente_fiscal) : null;
      return fiscal && (fiscal.id_cliente_fiscal || fiscal.cuit) ? fiscal : null;
    } catch {
      return null;
    }
  }, []);

  const actualizarCampoFiscal = useCallback((campo, valor) => {
    setForm((prev) => {
      const cuitActual = onlyDigits(prev.cuit);
      const base = normalizeFiscalData(prev.fiscalData || {
        cuit: cuitActual,
        doc_nro: cuitActual,
        doc_tipo: 80,
        origen: "manual",
        activo: 1,
      });

      const next = { ...base };

      if (campo === "cuit") {
        const cuit = onlyDigits(valor);
        next.cuit = cuit;
        next.doc_nro = cuit;
        return {
          ...prev,
          cuit,
          fiscalData: next,
          fiscalError: "",
          fiscalConsultado: false,
          cargaManual: false,
        };
      }

      if (campo === "razon_social") {
        next.razon_social = toUpperValue(valor);
        return {
          ...prev,
          nombre: toUpperValue(valor),
          fiscalData: next,
          fiscalError: "",
          cargaManual: false,
        };
      }

      next[campo] = campo === "condicion_iva" ? safeStr(valor) : String(valor ?? "");

      return {
        ...prev,
        fiscalData: next,
        fiscalError: "",
        cargaManual: false,
      };
    });
  }, []);

  const abrirDatosLegales = useCallback(async (row) => {
    const fiscalRow = fiscalFromClienteRow(row);
    setModalFiscal({
      open: true,
      row,
      fiscal: fiscalRow,
      loading: true,
    });

    const fiscalDb = await cargarFiscalCliente(getClienteId(row));

    setModalFiscal({
      open: true,
      row,
      fiscal: fiscalDb || fiscalRow,
      loading: false,
    });
  }, [cargarFiscalCliente]);

  const cerrarDatosLegales = useCallback(() => {
    if (modalFiscal.loading) return;
    setModalFiscal({ open: false, row: null, fiscal: null, loading: false });
  }, [modalFiscal.loading]);

  useEffect(() => {
    if (!open) return;
    cargarClientes(pestana);
    resetForm();
  }, [open, pestana, cargarClientes, resetForm]);

  const clientesOrdenados = useMemo(() => {
    return [...clientes].sort((a, b) =>
      String(a?.nombre || "").localeCompare(String(b?.nombre || ""), "es", {
        sensitivity: "base",
      })
    );
  }, [clientes]);

  const clientesFiltrados = useMemo(() => {
    const needle = normalizeSearch(busqueda);

    if (!needle) return clientesOrdenados;

    const needleDigits = onlyDigits(busqueda);

    return clientesOrdenados.filter((row) => {
      const fiscal = fiscalFromClienteRow(row);
      const nombre = normalizeSearch(row?.nombre);
      const razonSocial = normalizeSearch(fiscal?.razon_social || row?.razon_social || "");
      const cuit = onlyDigits(fiscal?.cuit || row?.cuit || "");
      const id = String(getClienteId(row));

      return (
        nombre.includes(needle) ||
        razonSocial.includes(needle) ||
        id.includes(needle) ||
        (needleDigits !== "" && cuit.includes(needleDigits))
      );
    });
  }, [clientesOrdenados, busqueda]);

  const iniciarEdicion = async (row, fiscalPreloaded = null) => {
    const fiscalRow = fiscalPreloaded || fiscalFromClienteRow(row);
    setModo("editar");
    setEditandoId(getClienteId(row));
    setForm({
      ...buildEmptyForm(Number(row?.activo ?? 1) === 1 ? 1 : 0),
      nombre: toUpperValue(row?.nombre),
      cuit: onlyDigits(fiscalRow?.cuit || row?.cuit || ""),
      fiscalData: fiscalRow,
      fiscalConsultado: !!fiscalRow,
      cargaManual: !fiscalRow,
    });

    if (fiscalPreloaded) return;

    const fiscalDb = await cargarFiscalCliente(getClienteId(row));
    if (fiscalDb) {
      setForm((prev) => ({
        ...prev,
        cuit: onlyDigits(fiscalDb.cuit || fiscalDb.doc_nro || prev.cuit),
        fiscalData: fiscalDb,
        fiscalConsultado: true,
        cargaManual: false,
      }));
    }
  };

  const editarDesdeModalFiscal = useCallback(() => {
    const row = modalFiscal.row;
    const fiscal = modalFiscal.fiscal;
    setModalFiscal({ open: false, row: null, fiscal: null, loading: false });
    if (row) iniciarEdicion(row, fiscal);
  }, [modalFiscal.row, modalFiscal.fiscal]);

  const cancelarEdicion = () => {
    resetForm();
  };

  const consultarArca = useCallback(async () => {
    const cuit = onlyDigits(form.cuit);

    if (cuit.length !== 11) {
      setForm((prev) => ({
        ...prev,
        fiscalError: "Ingresá un CUIT válido de 11 dígitos.",
        fiscalData: null,
        fiscalConsultado: true,
      }));
      return null;
    }

    setForm((prev) => ({
      ...prev,
      fiscalLoading: true,
      fiscalError: "",
      fiscalData: null,
      fiscalConsultado: false,
    }));

    try {
      const params = new URLSearchParams({
        action: "padron_cuit",
        op: "padron_cuit",
        cuit,
      });

      const data = await apiGet(`${API_URL}?${params.toString()}`);
      const summary = data?.data?.summary ?? data?.summary ?? data?.cliente ?? data?.data ?? null;
      const fiscal = normalizeFiscalData(summary);

      if (!fiscal.cuit || !fiscal.razon_social) {
        throw new Error("ARCA no devolvió datos completos para ese CUIT.");
      }

      setForm((prev) => ({
        ...prev,
        nombre: toUpperValue(fiscal.razon_social || prev.nombre),
        cuit: fiscal.cuit,
        fiscalData: fiscal,
        fiscalError: "",
        fiscalLoading: false,
        fiscalConsultado: true,
        cargaManual: false,
      }));

      onToast?.("exito", "Datos fiscales encontrados. Revisá y guardá el cliente.");
      return fiscal;
    } catch (err) {
      setForm((prev) => ({
        ...prev,
        fiscalData: null,
        fiscalError:
          err?.message ||
          "No se encontró el CUIT en ARCA. Podés cargar el cliente manualmente con el nombre solamente.",
        fiscalLoading: false,
        fiscalConsultado: true,
        cargaManual: true,
      }));
      return null;
    }
  }, [form.cuit, onToast]);

  const usarCargaManual = useCallback(() => {
    setForm((prev) => ({
      ...prev,
      cuit: "",
      fiscalData: null,
      fiscalError: "",
      fiscalLoading: false,
      fiscalConsultado: false,
      cargaManual: true,
    }));
    onToast?.("info", "Carga manual activada. Guardá solo el nombre del cliente.");
  }, [onToast]);

  const guardarConFiscal = async (payloadBase, fiscal) => {
    const f = normalizeFiscalData(fiscal);
    const data = await apiPost("cc_cliente_guardar_con_fiscal", {
      id_cliente: modo === "editar" ? editandoId : null,
      nombre: payloadBase.nombre,
      activo: payloadBase.activo,
      actualizar_nombre_cliente: 1,
      fiscal: {
        id_cliente_fiscal: f.id_cliente_fiscal,
        doc_tipo: Number(f.doc_tipo || 80),
        doc_nro: f.doc_nro || f.cuit,
        cuit: f.cuit,
        razon_social: f.razon_social,
        condicion_iva: f.condicion_iva,
        domicilio: f.domicilio,
        origen: f.origen || "arca_cuit",
        activo: 1,
      },
    });

    return data;
  };

  const handleGuardar = async () => {
    const payload = {
      nombre: toUpperValue(form.nombre).trim(),
      activo: Number(form.activo) === 1 ? 1 : 0,
    };

    const tieneFiscalValido = fiscalIsUsable(form.fiscalData);
    const cuitIngresado = onlyDigits(form.cuit);

    if (!payload.nombre && !tieneFiscalValido) {
      onToast?.("error", "El nombre del cliente es obligatorio. Si tiene CUIT, primero consultalo en ARCA.");
      return;
    }

    if (cuitIngresado && cuitIngresado.length !== 11) {
      onToast?.("error", "El CUIT debe tener 11 dígitos o dejarse vacío para cargar manualmente.");
      return;
    }

    if (cuitIngresado.length === 11 && !tieneFiscalValido) {
      onToast?.(
        "advertencia",
        "Ingresaste un CUIT pero todavía no hay datos de ARCA. Podés consultarlo o borrar el CUIT para guardarlo como cliente manual.",
        5200
      );
      return;
    }

    setSaving(true);

    try {
      let data;
      let tabDestino = payload.activo === 1 ? "activos" : "inactivos";

      if (tieneFiscalValido) {
        data = await guardarConFiscal(payload, form.fiscalData);
        const clienteGuardado = data?.cliente || null;
        tabDestino = Number(clienteGuardado?.activo ?? payload.activo) === 1 ? "activos" : "inactivos";
        onToast?.("exito", data?.mensaje || "Cliente y datos fiscales guardados correctamente.");
      } else if (modo === "crear") {
        data = await apiPost("cc_cliente_crear", payload);
        onToast?.("exito", data?.mensaje || "Cliente creado correctamente.");
      } else {
        data = await apiPost("cc_cliente_actualizar", {
          id_cliente: editandoId,
          ...payload,
        });
        onToast?.("exito", data?.mensaje || "Cliente actualizado correctamente.");
      }

      setPestana(tabDestino);
      await cargarClientes(tabDestino);
      await onActualizado?.();
      resetForm();
    } catch (err) {
      onToast?.("error", err?.message || "No se pudo guardar el cliente.");
    } finally {
      setSaving(false);
    }
  };

  const abrirModalAccion = useCallback((type, row) => {
    setModalAccion({
      open: true,
      type,
      row,
      loading: false,
    });
  }, []);

  const cerrarModalAccion = useCallback(() => {
    if (modalAccion.loading) return;

    setModalAccion({
      open: false,
      type: null,
      row: null,
      loading: false,
    });
  }, [modalAccion.loading]);

  const ejecutarAccionModal = useCallback(async () => {
    const { row, type } = modalAccion;
    const id = getClienteId(row);

    if (!id || !type) {
      throw new Error("No se encontró el cliente seleccionado.");
    }

    setModalAccion((prev) => ({ ...prev, loading: true }));
    setAccionandoId(id);

    try {
      let action = "";
      let successFallback = "";

      if (type === "baja") {
        action = "cc_cliente_dar_baja";
        successFallback = "Cliente dado de baja correctamente.";
      } else if (type === "alta") {
        action = "cc_cliente_dar_alta";
        successFallback = "Cliente dado de alta correctamente.";
      } else if (type === "eliminar") {
        action = "cc_cliente_eliminar";
        successFallback = "Cliente eliminado correctamente.";
      } else {
        throw new Error("Acción inválida.");
      }

      const data = await apiPost(action, { id_cliente: id });

      onToast?.("exito", data?.mensaje || successFallback);

      if ((type === "baja" || type === "eliminar") && id === Number(editandoId || 0)) {
        resetForm();
      }

      await cargarClientes(pestana);
      await onActualizado?.();

      setModalAccion({
        open: false,
        type: null,
        row: null,
        loading: false,
      });
    } catch (err) {
      onToast?.("error", err?.message || "No se pudo completar la acción.");
    } finally {
      setAccionandoId(null);
      setModalAccion((prev) => ({ ...prev, loading: false }));
    }
  }, [
    modalAccion,
    editandoId,
    cargarClientes,
    pestana,
    onActualizado,
    onToast,
    resetForm,
  ]);

  const modalConfig = useMemo(() => {
    const row = modalAccion.row;
    const nombre = String(row?.nombre || "—");
    const activo = Number(row?.activo ?? 1) === 1;
    const fiscal = fiscalFromClienteRow(row);
    const detailsBase = [
      { label: "ID Cliente", value: `#${getClienteId(row)}` },
      { label: "Nombre", value: nombre },
      ...(fiscal?.cuit ? [{ label: "CUIT", value: fiscal.cuit }] : []),
    ];

    if (modalAccion.type === "baja") {
      return {
        title: "Dar de baja cliente",
        message: "¿Seguro que querés dar de baja este cliente?",
        warning: "El cliente pasará a la pestaña de inactivos.",
        loadingMessage: "Dando de baja cliente...",
        successMessage: "Cliente dado de baja correctamente.",
        errorMessage: "No se pudo dar de baja el cliente.",
        confirmLabel: "Dar de baja",
        confirmVariant: "danger",
        details: [...detailsBase, { label: "Estado actual", value: "Activo" }],
      };
    }

    if (modalAccion.type === "alta") {
      return {
        title: "Dar de alta cliente",
        message: "¿Seguro que querés dar de alta este cliente?",
        warning: "El cliente volverá a la pestaña de activos.",
        loadingMessage: "Dando de alta cliente...",
        successMessage: "Cliente dado de alta correctamente.",
        errorMessage: "No se pudo dar de alta el cliente.",
        confirmLabel: "Dar de alta",
        confirmVariant: "primary",
        details: [...detailsBase, { label: "Estado actual", value: "Inactivo" }],
      };
    }

    return {
      title: "Eliminar cliente",
      message: "¿Seguro que querés eliminar este cliente definitivamente?",
      warning: "Esta acción no se puede deshacer.",
      loadingMessage: "Eliminando cliente...",
      successMessage: "Cliente eliminado correctamente.",
      errorMessage: "No se pudo eliminar el cliente.",
      confirmLabel: "Eliminar",
      confirmVariant: "danger",
      details: [...detailsBase, { label: "Estado", value: activo ? "Activo" : "Inactivo" }],
    };
  }, [modalAccion]);

  if (!open) return null;

  return createPortal(
    <div
      className={[
        "mi-modal__overlay",
        dark ? "mi-modal__overlay--dark" : "",
      ].join(" ").trim()}
    >
      <div
        className={[
          "mi-modal__container",
          "mi-modal__container--categorias",
          dark ? "mi-modal--dark" : "",
        ].join(" ").trim()}
        role="dialog"
        aria-modal="true"
        onMouseDown={(e) => e.stopPropagation()}
      >
        <div className="mi-modal__header">
          <div className="mi-modal__head-icon" aria-hidden="true">
            <FontAwesomeIcon icon={faUsers} />
          </div>

          <div className="mi-modal__head-left">
            <h2 className="mi-modal__title">Clientes</h2>
            <p className="mi-modal__subtitle">
              Agregá o editá clientes combinando datos simples y datos fiscales de ARCA.
            </p>
          </div>

          <button
            ref={closeBtnRef}
            type="button"
            className="mi-modal__close"
            disabled={isBusy}
            onClick={() => onClose?.()}
            aria-label="Cerrar"
          >
            <FontAwesomeIcon icon={faXmark} />
          </button>
        </div>

        <div className="mi-modal__content">
          <div className="mi-cr-grid">
            <aside className="mi-cr-filters">
              <div className="mi-cr-filters__top">
                <div className="mi-cr-filters__title">
                  <FontAwesomeIcon
                    icon={modo === "crear" ? faPlus : faPenToSquare}
                    style={{ marginRight: 8, opacity: 0.75, fontSize: 13 }}
                  />
                  {modo === "crear" ? "Nuevo cliente" : "Editar cliente"}
                </div>
              </div>

              <div className="mi-cr-filters__body">
                <div
                  style={{
                    border: "1px solid rgba(59, 130, 246, 0.22)",
                    background: "rgba(59, 130, 246, 0.08)",
                    borderRadius: 12,
                    padding: "10px 12px",
                    fontSize: 12,
                    color: "var(--nv-text)",
                    lineHeight: 1.45,
                  }}
                >
                  <b style={{ display: "flex", gap: 7, alignItems: "center", marginBottom: 4 }}>
                    <FontAwesomeIcon icon={faFileInvoiceDollar} /> Cliente fiscal o manual
                  </b>
                  Ingresá CUIT para traer datos de ARCA. Si no aparece o es venta informal, dejá el CUIT vacío y cargá solo el nombre.
                </div>

                <div className="fl-field">
                  <input
                    type="text"
                    inputMode="numeric"
                    maxLength={11}
                    className="fl-input"
                    placeholder=" "
                    value={form.cuit}
                    onChange={(e) =>
                      setForm((prev) => {
                        const cuit = onlyDigits(e.target.value);
                        const fiscalActual = fiscalHasAnyData(prev.fiscalData)
                          ? { ...normalizeFiscalData(prev.fiscalData), cuit, doc_nro: cuit }
                          : null;

                        return {
                          ...prev,
                          cuit,
                          fiscalData: fiscalActual,
                          fiscalError: "",
                          fiscalConsultado: false,
                          cargaManual: !fiscalActual,
                        };
                      })
                    }
                    disabled={saving || form.fiscalLoading}
                  />
                  <label className="fl-label">
                    <FontAwesomeIcon icon={faIdCard} style={{ marginRight: 5 }} />
                    CUIT ARCA
                  </label>
                </div>

                <div className="mi-cr-filters__actions" style={{ flexDirection: "row", marginTop: 0 }}>
                  <button
                    type="button"
                    className="mit-btn mit-btn--ghost mit-btn--block"
                    onClick={consultarArca}
                    disabled={saving || form.fiscalLoading || onlyDigits(form.cuit).length !== 11}
                  >
                    <FontAwesomeIcon icon={faMagnifyingGlass} style={{ marginRight: 8 }} />
                    {form.fiscalLoading ? "Consultando..." : "Consultar ARCA"}
                  </button>

                  <button
                    type="button"
                    className="mit-btn mit-btn--ghost mit-btn--block"
                    onClick={usarCargaManual}
                    disabled={saving || form.fiscalLoading}
                    title="Cargar cliente sin datos fiscales"
                  >
                    Sin CUIT
                  </button>
                </div>

                {form.fiscalError && (
                  <div
                    style={{
                      border: "1px solid rgba(239, 68, 68, 0.25)",
                      background: "rgba(239, 68, 68, 0.08)",
                      borderRadius: 12,
                      padding: "9px 11px",
                      fontSize: 12,
                      color: dark ? "#fecaca" : "#b91c1c",
                      lineHeight: 1.45,
                    }}
                  >
                    {form.fiscalError} Completá el nombre y guardalo sin CUIT si corresponde.
                  </div>
                )}

                <FiscalResumen fiscal={form.fiscalData} />

                <FiscalEditableFields
                  fiscal={form.fiscalData}
                  cuit={form.cuit}
                  saving={saving}
                  fiscalLoading={form.fiscalLoading}
                  dark={dark}
                  onFieldChange={actualizarCampoFiscal}
                />

                <div className="fl-field">
                  <input
                    type="text"
                    className="fl-input"
                    placeholder=" "
                    value={form.nombre}
                    onChange={(e) =>
                      setForm((prev) => ({
                        ...prev,
                        nombre: toUpperValue(e.target.value),
                      }))
                    }
                    disabled={saving || form.fiscalLoading}
                  />
                  <label className="fl-label">
                    <FontAwesomeIcon icon={faUser} style={{ marginRight: 5 }} />
                    Nombre / razón social *
                  </label>
                </div>

                <div className="fl-field">
                  <select
                    className="fl-input"
                    value={String(form.activo)}
                    onChange={(e) =>
                      setForm((prev) => ({
                        ...prev,
                        activo: Number(e.target.value) === 1 ? 1 : 0,
                      }))
                    }
                    disabled={saving || form.fiscalLoading}
                  >
                    <option value="1">Activo</option>
                    <option value="0">Inactivo</option>
                  </select>
                  <label className="fl-label">Estado</label>
                </div>

                <div className="mi-cr-filters__actions" style={{ flexDirection: "row" }}>
                  <button
                    type="button"
                    className="mit-btn mit-btn--solid mit-btn--block"
                    onClick={handleGuardar}
                    disabled={saving || form.fiscalLoading}
                  >
                    <FontAwesomeIcon icon={faFloppyDisk} style={{ marginRight: 8 }} />
                    {saving
                      ? "Guardando..."
                      : modo === "crear"
                      ? fiscalIsUsable(form.fiscalData)
                        ? "Crear cliente fiscal"
                        : "Crear cliente"
                      : fiscalIsUsable(form.fiscalData)
                      ? "Guardar cliente fiscal"
                      : "Guardar"}
                  </button>

                  {modo === "editar" && (
                    <button
                      type="button"
                      className="mit-btn mit-btn--ghost mit-btn--block"
                      onClick={cancelarEdicion}
                      disabled={saving || form.fiscalLoading}
                    >
                      Cancelar
                    </button>
                  )}
                </div>
              </div>
            </aside>

            <section className="mi-cr-table">
              <div className="mi-cr-table__foot mi-cr-table__foot--top">
                <div className="mi-cr-table__summary">
                  <div>
                    <div style={{ fontSize: 13, fontWeight: 700, color: "var(--nv-text)" }}>
                      Listado de clientes
                    </div>
                    <div style={{ fontSize: 12, color: "var(--nv-muted)" }}>
                      Total: <b>{clientesFiltrados.length}</b>
                      {busqueda.trim() && (
                        <>
                          {" "}
                          / {clientesOrdenados.length}
                        </>
                      )}
                    </div>
                  </div>
                </div>
                <div className="cc-filter cc-filter--search" id="vents-comppr-wits">
                  <div className="cc-floatingField cc-floatingField--search is-active">
                    <div className="cc-searchInput">
                      <div className="cc-searchInput__fieldWrap cc-field">
                        <input
                          className="cc-input cc-input--floating"
                          value={busqueda}
                          onChange={(e) => setBusqueda(e.target.value)}
                          placeholder="Buscar por cliente o CUIT..."
                          disabled={loading || saving || modalAccion.loading}
                        />

                        <span className="cc-floatingLabel">
                          <FontAwesomeIcon icon={faMagnifyingGlass} /> Búsqueda
                        </span>

                        {busqueda.trim() !== "" && !loading && (
                          <button
                            type="button"
                            className="cc-clearSearch cc-clearSearch--inside"
                            onClick={() => setBusqueda("")}
                            disabled={saving || modalAccion.loading}
                            title="Limpiar búsqueda"
                          >
                            <FontAwesomeIcon icon={faXmark} />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
                <div style={{ display: "flex", gap: 8 }}>
                  <button
                    type="button"
                    className={`mit-btn ${pestana === "activos" ? "mit-btn--solid" : "mit-btn--ghost"}`}
                    onClick={() => {
                      setPestana("activos");
                      setModo("crear");
                      setEditandoId(null);
                      setForm(buildEmptyForm(1));
                    }}
                    disabled={loading || saving || modalAccion.loading}
                  >
                    Activos
                  </button>

                  <button
                    type="button"
                    className={`mit-btn ${pestana === "inactivos" ? "mit-btn--solid" : "mit-btn--ghost"}`}
                    onClick={() => {
                      setPestana("inactivos");
                      setModo("crear");
                      setEditandoId(null);
                      setForm(buildEmptyForm(0));
                    }}
                    disabled={loading || saving || modalAccion.loading}
                  >
                    Inactivos
                  </button>
                </div>
              </div>

              <div className="cc-cliente-table">
                <div className="cc-cliente-table__desktopHead">
                  <div className="cc-grid-header">
                    <div className="cc-grid-header__cell">Cliente</div>
                    <div className="cc-grid-header__cell">Estado</div>
                    <div className="cc-grid-header__cell">Acciones</div>
                  </div>
                </div>

                <div className="cc-cliente-table__body">
                  {loading ? (
                    <div className="cc-loading-state">
                      <FontAwesomeIcon icon={faArrowRotateRight} spin />
                      <span>Cargando clientes...</span>
                    </div>
                  ) : clientesFiltrados.length === 0 ? (
                    <div className="cc-empty-state">
                      <FontAwesomeIcon icon={faUsers} />
                      <span>
                        {busqueda.trim()
                          ? `No se encontraron clientes para "${busqueda}".`
                          : pestana === "activos"
                          ? "No hay clientes activos."
                          : "No hay clientes inactivos."}
                      </span>
                    </div>
                  ) : (
                    <div className="cc-grid-rows">
                      {clientesFiltrados.map((row) => {
                        const activo = Number(row?.activo ?? 1) === 1;
                        const bloqueado =
                          accionandoId === getClienteId(row) ||
                          saving ||
                          modalAccion.loading;
                        const fiscal = fiscalFromClienteRow(row);
                        // ── Solo mostrar botón fiscal si el cliente tiene CUIT ──
                        const tieneCuit = !!fiscal?.cuit;

                        return (
                          <div key={getClienteId(row)} className="cc-grid-row">
                            <div className="cc-grid-cell">
                              <span
                                className="cc-ellipsis-text"
                                title={row?.nombre || "—"}
                                style={{ display: "block" }}
                              >
                                {row?.nombre || "—"}
                              </span>
                              <span
                                style={{
                                  display: "block",
                                  marginTop: 3,
                                  fontSize: 11,
                                  color: "var(--nv-muted)",
                                  fontWeight: 500,
                                  overflow: "hidden",
                                  textOverflow: "ellipsis",
                                  whiteSpace: "nowrap",
                                }}
                                title={tieneCuit ? `${fiscal.cuit} - ${fiscal.razon_social || ""}` : "Cliente sin datos fiscales"}
                              >
                                {tieneCuit ? `CUIT ${fiscal.cuit}` : "Sin datos fiscales / manual"}
                              </span>
                            </div>

                            <div className="cc-grid-cell">
                              <span
                                className={`cc-status-badge ${
                                  activo
                                    ? "cc-status-badge--active"
                                    : "cc-status-badge--inactive"
                                }`}
                              >
                                {activo ? "Activo" : "Inactivo"}
                              </span>
                            </div>

                            <div className="cc-grid-cell">
                              <div className="cc-actions-group">
                                {/* ── Botón datos fiscales: solo si tiene CUIT ── */}
                                {tieneCuit && (
                                  <button
                                    type="button"
                                    className="cc-action-btn"
                                    onClick={() => abrirDatosLegales(row)}
                                    disabled={bloqueado}
                                    title="Ver datos legales"
                                  >
                                    <FontAwesomeIcon icon={faFileInvoiceDollar} />
                                  </button>
                                )}

                                {activo ? (
                                  <>
                                    <button
                                      type="button"
                                      className="cc-action-btn"
                                      onClick={() => iniciarEdicion(row)}
                                      disabled={bloqueado}
                                      title="Editar"
                                    >
                                      <FontAwesomeIcon icon={faPenToSquare} />
                                    </button>

                                    <button
                                      type="button"
                                      className="cc-action-btn"
                                      onClick={() => abrirModalAccion("baja", row)}
                                      disabled={bloqueado}
                                      title="Dar de baja"
                                    >
                                      <FontAwesomeIcon icon={faUserSlash} />
                                    </button>
                                  </>
                                ) : (
                                  <button
                                    type="button"
                                    className="cc-action-btn"
                                    onClick={() => abrirModalAccion("alta", row)}
                                    disabled={bloqueado}
                                    title="Dar de alta"
                                  >
                                    <FontAwesomeIcon icon={faUserCheck} />
                                  </button>
                                )}

                                <button
                                  type="button"
                                  className="cc-action-btn cc-action-btn--danger"
                                  onClick={() => abrirModalAccion("eliminar", row)}
                                  disabled={bloqueado}
                                  title="Eliminar"
                                >
                                  <FontAwesomeIcon icon={faTrashCan} />
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                <div className="cc-cliente-table__footWrap">
                  <span style={{ fontSize: 12, color: "var(--nv-muted)" }}>
                    Administrá el padrón de <b>clientes</b> y sus <b>datos fiscales</b>.
                  </span>
                </div>
              </div>
            </section>
          </div>
        </div>

        <div className="mit-actions">
          <span className="mit-help">
            Clientes simples para cuenta corriente y clientes fiscales para facturación ARCA.
          </span>
          <button
            type="button"
            className="mit-btn mit-btn--ghost"
            onClick={() => onClose?.()}
            disabled={isBusy}
          >
            Cerrar
          </button>
        </div>
      </div>

      <ModalDatosLegalesCliente
        open={modalFiscal.open}
        dark={dark}
        row={modalFiscal.row}
        fiscal={modalFiscal.fiscal}
        loading={modalFiscal.loading}
        onClose={cerrarDatosLegales}
        onEdit={editarDesdeModalFiscal}
      />

      <ModalEliminar
        open={modalAccion.open}
        row={
          modalAccion.row
            ? {
                id: getClienteId(modalAccion.row),
                nombre: modalAccion.row?.nombre || "—",
                estado:
                  Number(modalAccion.row?.activo ?? 1) === 1 ? "Activo" : "Inactivo",
              }
            : null
        }
        loading={modalAccion.loading}
        onClose={cerrarModalAccion}
        onConfirm={ejecutarAccionModal}
        onToast={onToast}
        title={modalConfig.title}
        message={modalConfig.message}
        warning={modalConfig.warning}
        loadingMessage={modalConfig.loadingMessage}
        successMessage={modalConfig.successMessage}
        errorMessage={modalConfig.errorMessage}
        confirmLabel={modalConfig.confirmLabel}
        cancelLabel="Cancelar"
        confirmVariant={modalConfig.confirmVariant}
        details={modalConfig.details}
      />
    </div>,
    document.body
  );
}