import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import "../../../Global/Global_css/Global_Modals.css";
import "../../../Global/Global_css/Global_responsive.css";
import "../../../Global/Global_css/roots.css";
import "../DocumentosComerciales.css";
import BASE_URL from "../../../../config/config";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faCheckCircle,
  faFileInvoiceDollar,
  faFloppyDisk,
  faSpinner,
  faTriangleExclamation,
  faXmark,
} from "@fortawesome/free-solid-svg-icons";
import ModalFacturaBaltoResumen from "../../Facturacion/ModalFacturaBaltoResumen.jsx";
import { PanelMediosPagoInlineVenta } from "../../Ventas/modales/ModalNuevaVenta.jsx";
import { saveVentaNoFacturadaPdf } from "../../../../utils/VentaNoFacturadaPdfBuilder";
import { saveRemitoPdf } from "../../../../utils/RemitoPdfBuilder";

const NULL_OPTION = "";
const API = `${BASE_URL}/api.php`;
const API_PRESUPUESTO_GET = `${API}?action=presupuestos_obtener`;
const API_CONVERTIR = `${API}?action=presupuestos_convertir_venta`;
const API_CONFIG_FACTURACION = `${API}?action=config_facturacion_get`;
const API_CLIENTE_FISCAL_GET = `${API}?action=cliente_fiscal_get`;
const API_CLIENTE_FISCAL_SAVE = `${API}?action=cliente_fiscal_upsert`;
const API_PADRON_CUIT = `${API}?action=padron_cuit&op=padron_cuit`;
const API_VINCULAR_COMPROBANTE = `${API}?action=ventas_comprobantes_vincular_movimiento`;
const API_CHEQUES_ACTUALIZAR = `${API}?action=ventas_cheques_actualizar`;

function todayISO() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function plusDaysISOFrom(baseIso, days = 10) {
  const base = String(baseIso || todayISO()).slice(0, 10);
  const d = /^\d{4}-\d{2}-\d{2}$/.test(base) ? new Date(`${base}T00:00:00`) : new Date();
  d.setDate(d.getDate() + Number(days || 0));
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function safeNumber(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

function safeStr(v) {
  return String(v ?? "").trim();
}

function safeText(v) {
  const s = safeStr(v);
  return s || "—";
}

function onlyDigits(v) {
  return String(v ?? "").replace(/\D+/g, "");
}

function normalizeText(v) {
  return String(v ?? "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function moneyARS(v) {
  const n = safeNumber(v);
  try {
    return n.toLocaleString("es-AR", {
      style: "currency",
      currency: "ARS",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  } catch {
    return `$ ${n.toFixed(2)}`;
  }
}

function formatFechaDMY(v) {
  const s = safeStr(v);
  if (!s) return "—";
  const m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (m) return `${String(Number(m[3])).padStart(2, "0")}/${String(Number(m[2])).padStart(2, "0")}/${m[1]}`;
  return s;
}

function getAuthInfo() {
  let usuario = null;
  try {
    usuario = JSON.parse(localStorage.getItem("usuario") || "null");
  } catch {
    usuario = null;
  }
  return {
    usuario,
    token: localStorage.getItem("token") || localStorage.getItem("auth_token") || "",
    sessionKey: localStorage.getItem("session_key") || "",
  };
}

function buildAuthHeaders(isJson = true) {
  const { token, sessionKey } = getAuthInfo();
  const headers = {};
  if (isJson) headers["Content-Type"] = "application/json";
  if (sessionKey) headers["X-Session"] = sessionKey;
  else if (token) headers.Authorization = `Bearer ${token}`;
  return headers;
}

function getIdUsuarioLocal() {
  const { usuario } = getAuthInfo();
  return Number(usuario?.id_usuario ?? usuario?.idUsuario ?? usuario?.id ?? 0) || null;
}

async function parseJsonOrThrow(res) {
  const text = await res.text();
  if (!text) throw new Error("Respuesta vacía del servidor.");
  let data;
  try {
    data = JSON.parse(text);
  } catch {
    throw new Error(`Respuesta inválida del servidor. HTTP ${res.status}`);
  }
  if (!res.ok || data?.exito === false) throw new Error(data?.mensaje || data?.error || `HTTP ${res.status}`);
  return data;
}

async function apiGetJson(url) {
  const res = await fetch(url, { method: "GET", headers: buildAuthHeaders(false) });
  return await parseJsonOrThrow(res);
}

async function apiPostJson(url, payload) {
  const res = await fetch(url, {
    method: "POST",
    headers: buildAuthHeaders(true),
    body: JSON.stringify(payload ?? {}),
  });
  return await parseJsonOrThrow(res);
}

function buildFormHeaders() {
  return buildAuthHeaders(false);
}

function getMovimientoId(r) {
  const n = Number(r?.id_movimiento ?? r?.idMovimiento ?? r?.id ?? 0);
  return Number.isFinite(n) && n > 0 ? n : null;
}

function getClienteId(r) {
  const n = Number(r?.id_cliente ?? r?.cliente_id ?? r?.idCliente ?? 0);
  return Number.isFinite(n) && n > 0 ? n : null;
}

function getTipoVentaId(t) {
  const n = Number(t?.id_tipo_venta ?? t?.id ?? t?.value ?? 0);
  return Number.isFinite(n) && n > 0 ? n : null;
}

function getMedioPagoId(mp) {
  const n = Number(mp?.id_medio_pago ?? mp?.id ?? mp?.value ?? 0);
  return Number.isFinite(n) && n > 0 ? n : null;
}

function getMedioPagoNombre(mp) {
  return safeStr(mp?.nombre ?? mp?.descripcion ?? mp?.detalle ?? mp?.label ?? mp?.medio_pago ?? "");
}

function isContadoTipoVenta(tipo) {
  const n = normalizeText(tipo?.nombre ?? tipo?.descripcion ?? tipo?.detalle ?? tipo?.label ?? tipo ?? "");
  return n.includes("contado") || n.includes("efectivo") || n === "cash";
}

function isCuentaCorrienteTipoVenta(tipo) {
  const n = normalizeText(tipo?.nombre ?? tipo?.descripcion ?? tipo?.detalle ?? tipo?.label ?? tipo ?? "");
  return n.includes("cuenta corriente") || n.includes("cta corriente") || n.includes("credito") || n.includes("crédito");
}

function normalizeChequeTipoFromMedio(nombre) {
  const n = normalizeText(nombre);
  if (n.includes("echeq") || n.includes("e-cheq") || n.includes("e cheq")) return "echeq";
  if (n.includes("cheque")) return "cheque";
  return null;
}

function normalizeList(arr) {
  return Array.isArray(arr) ? arr.filter(Boolean) : [];
}

function normalizeLists(lists) {
  const l = lists && typeof lists === "object" ? lists : {};
  return {
    tiposVenta: normalizeList(l.tiposVenta || l.tipos_venta || l.tipoVenta || []),
    mediosPago: normalizeList(l.mediosPago || l.medios_pago || l.medioPago || []),
  };
}

function normalizeItem(it, i = 0) {
  const cantidad = safeNumber(it?.cantidad ?? it?.cant ?? 0);
  const precio = safeNumber(it?.precio ?? it?.precio_unitario ?? it?.importe_unitario ?? 0);
  const ivaPct = safeNumber(it?.iva_pct ?? it?.ivaPct ?? it?.iva ?? 0);
  const subtotal = safeNumber(it?.subtotal) || cantidad * precio;
  const ivaMonto = safeNumber(it?.iva_monto ?? it?.ivaMonto) || subtotal * ivaPct / 100;
  const total = safeNumber(it?.total ?? it?.ars) || subtotal + ivaMonto;

  return {
    id: it?.id || it?.id_item || `item-${i + 1}`,
    id_detalle: null,
    id_stock_producto: Number(it?.id_stock_producto ?? it?.idStockProducto ?? 0) || null,
    codigo: safeStr(it?.codigo || it?.codigo_producto || i + 1),
    descripcion: safeStr(it?.descripcion || it?.detalle || it?.nombre || it?.producto || it?.nombre_producto || "Producto o servicio"),
    cantidad,
    unidad: safeStr(it?.unidad || "u"),
    precio_unitario: precio,
    precio,
    bonif_pct: 0,
    impBonif: 0,
    subtotal,
    ars: total,
    iva_pct: ivaPct,
    iva_monto: ivaMonto,
    total,
  };
}

function normalizeClienteFiscalDb(data) {
  const s = data && typeof data === "object" ? data : {};
  return {
    id_cliente_fiscal: Number(s.id_cliente_fiscal || 0) || null,
    id_cliente: Number(s.id_cliente || 0) || null,
    doc_tipo: Number(s.doc_tipo || 80) || 80,
    doc_nro: safeStr(s.doc_nro || s.cuit),
    cuit: safeStr(s.cuit || s.doc_nro),
    razon_social: safeStr(s.razon_social || s.nombre || s.cliente),
    condicion_iva: safeStr(s.condicion_iva || s.cond_iva || s.iva),
    cond_iva: safeStr(s.cond_iva || s.condicion_iva || s.iva),
    domicilio: safeStr(s.domicilio || s.direccion),
    origen: safeStr(s.origen || "db"),
  };
}

function normalizeArcaSummary(s) {
  const x = s && typeof s === "object" ? s : {};
  return {
    cuit: safeStr(x.cuit || x.doc_nro),
    razon_social: safeStr(x.razon_social || x.nombre || x.denominacion || x.apellido_nombre),
    condicion_iva: safeStr(x.condicion_iva || x.cond_iva || x.iva || x.descripcion_iva),
    cond_iva: safeStr(x.cond_iva || x.condicion_iva || x.iva || x.descripcion_iva),
    domicilio: safeStr(x.domicilio || x.direccion || x.direccion_fiscal),
    doc_tipo: 80,
    doc_nro: safeStr(x.cuit || x.doc_nro),
    origen: "arca_cuit",
  };
}

function normalizeConfigFacturacionPdf(cfg) {
  const c = cfg && typeof cfg === "object" ? cfg : {};
  const razon = safeStr(c.razon_social || c.nombre_fantasia || c.nombre || c.emisor_razon_social || "BALTO");
  const domicilio = safeStr(
    c.domicilio_comercial ||
      c.emisor_domicilio ||
      c.domicilio ||
      c.domicilio_fiscal ||
      c.direccion ||
      ""
  );
  const condicionIva = safeStr(c.condicion_iva || c.cond_iva || c.iva || c.emisor_condicion_iva || "");
  const ingresosBrutos = safeStr(c.ingresos_brutos || c.iibb || "");
  const inicio = safeStr(c.fecha_inicio_actividades || c.inicio_actividades || "");
  const cuit = safeStr(c.cuit || c.emisor_cuit || "");
  const logoUrl = safeStr(c.logo_url || "");

  return {
    raw: c,
    config_pdf: c,
    emisor_nombre: razon,
    emisor_domicilio: domicilio,
    cuit_emisor: cuit,
    cond_iva_emisor: condicionIva,
    ingresos_brutos_emisor: ingresosBrutos,
    fecha_inicio_actividades_emisor: inicio,
    logo_url: logoUrl,
    emisor: {
      razon_social: razon,
      nombre_fantasia: safeStr(c.nombre_fantasia || ""),
      domicilio_comercial: domicilio,
      domicilio_fiscal: domicilio,
      domicilio,
      direccion: domicilio,
      cuit,
      condicion_iva: condicionIva,
      cond_iva: condicionIva,
      ingresos_brutos: ingresosBrutos,
      iibb: ingresosBrutos,
      fecha_inicio_actividades: inicio,
      inicio_actividades: inicio,
      punto_venta: safeStr(c.punto_venta || ""),
      tipo_comprobante_default: safeStr(c.tipo_comprobante_default || ""),
      codigo_comprobante: safeStr(c.codigo_comprobante || ""),
      logo_url: logoUrl,
    },
  };
}

function buildClienteFiscalPdf(fiscal, clienteBase, nombreFallback) {
  const f = fiscal && typeof fiscal === "object" ? fiscal : {};
  const c = clienteBase && typeof clienteBase === "object" ? clienteBase : {};
  const cuit = safeStr(f.cuit || f.doc_nro || c.cuit || c.doc_nro);
  return {
    id_cliente: Number(f.id_cliente || c.id_cliente || 0) || null,
    doc_tipo: Number(f.doc_tipo || (cuit ? 80 : 99)) || 99,
    doc_nro: safeStr(f.doc_nro || cuit || c.doc_nro),
    cuit,
    razon_social: safeStr(f.razon_social || c.razon_social || c.nombre || nombreFallback || "Cliente"),
    cond_iva: safeStr(f.cond_iva || f.condicion_iva || c.cond_iva || c.condicion_iva),
    condicion_iva: safeStr(f.condicion_iva || f.cond_iva || c.condicion_iva || c.cond_iva),
    domicilio: safeStr(f.domicilio || c.domicilio || c.direccion),
    origen: safeStr(f.origen || "documento_comercial"),
  };
}

function buildMediosPagoPayload(mediosFilas, mediosPagoList) {
  return (Array.isArray(mediosFilas) ? mediosFilas : [])
    .filter((mp) => mp?.id_medio_pago && mp.id_medio_pago !== "")
    .map((mp) => {
      const mpRow = mediosPagoList.find((x) => String(getMedioPagoId(x) ?? "") === String(mp.id_medio_pago));
      const medioPagoNombre = getMedioPagoNombre(mpRow);
      const tipoCheque = normalizeChequeTipoFromMedio(medioPagoNombre);

      const base = {
        frontend_row_uid: mp.id,
        id_medio_pago: Number(mp.id_medio_pago),
        nombre: medioPagoNombre,
        medio_pago: medioPagoNombre,
        descripcion: medioPagoNombre,
        monto: tipoCheque !== null ? safeNumber(mp.cheque?.importe) : safeNumber(mp.monto),
      };

      if (tipoCheque !== null && mp.cheque) {
        return {
          ...base,
          cheque: {
            tipo: tipoCheque,
            fecha_emision: mp.cheque.fecha_emision,
            emisor: mp.cheque.emisor,
            numero_cheque: mp.cheque.numero_cheque,
            importe: safeNumber(mp.cheque.importe),
            fecha_pago: mp.cheque.fecha_pago,
            observaciones: mp.cheque.observaciones || "",
            archivo_nombre:
              mp.cheque.archivo_nombre ||
              (mp.cheque.archivo instanceof File ? mp.cheque.archivo.name : ""),
          },
        };
      }

      return base;
    });
}

function formatEditableMoney(v) {
  const n = safeNumber(v);
  if (!n) return "";
  return String(n).replace(".", ",");
}

function buildEmptyMedioPago(total = 0) {
  const id = typeof crypto !== "undefined" && crypto.randomUUID ? crypto.randomUUID() : `mp-${Date.now()}-${Math.random()}`;
  return {
    id,
    id_medio_pago: NULL_OPTION,
    monto: safeNumber(total),
    montoDraft: formatEditableMoney(total),
    montoFocused: false,
    cheque: null,
  };
}

function getChequeFileFromRows(rows, uid) {
  const row = (Array.isArray(rows) ? rows : []).find((r) => String(r.id) === String(uid));
  const file = row?.cheque?.archivo;
  return file instanceof File ? file : null;
}

export default function ModalAsignarPresupuestoVenta({
  open,
  row,
  lists,
  onClose,
  onSaved,
  onToast,
}) {
  const showToast = useCallback(
    (tipo, mensaje, duracion = 3600) => {
      if (typeof onToast === "function") onToast(tipo, mensaje, duracion);
    },
    [onToast]
  );

  const listas = useMemo(() => normalizeLists(lists), [lists]);
  const mediosPagoList = useMemo(() => listas.mediosPago, [listas.mediosPago]);
  const tiposVentaList = useMemo(() => listas.tiposVenta, [listas.tiposVenta]);

  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [detalle, setDetalle] = useState(null);
  const [fecha, setFecha] = useState(todayISO());
  const [idTipoVenta, setIdTipoVenta] = useState("");
  const [mediosFilas, setMediosFilas] = useState([]);
  const [clienteFiscalDb, setClienteFiscalDb] = useState(null);
  const [fiscalCuitInput, setFiscalCuitInput] = useState("");
  const [fiscalArcaData, setFiscalArcaData] = useState(null);
  const [fiscalLoading, setFiscalLoading] = useState(false);
  const [openResumenFactura, setOpenResumenFactura] = useState(false);
  const [resumenFacturaData, setResumenFacturaData] = useState(null);
  const [fiscalParaFacturar, setFiscalParaFacturar] = useState(null);
  const abortRef = useRef(null);

  const convertido = Number(row?.convertido_a_venta ?? row?.convertido ?? 0) === 1;
  const idPresupuesto = useMemo(() => getMovimientoId(row), [row]);

  const clienteBase = useMemo(() => {
    const mov = detalle?.presupuesto || detalle?.movimiento || row || {};
    return {
      id_cliente: getClienteId(mov) || getClienteId(row),
      nombre: safeStr(mov?.cliente || mov?.cliente_nombre || row?.cliente || row?.cliente_nombre || "Cliente"),
      razon_social: safeStr(mov?.razon_social || row?.razon_social || ""),
      domicilio: safeStr(mov?.domicilio || row?.domicilio || ""),
    };
  }, [detalle, row]);

  const items = useMemo(() => {
    const arr = Array.isArray(detalle?.items) ? detalle.items : [];
    return arr.map(normalizeItem);
  }, [detalle]);

  const total = useMemo(() => {
    const mov = detalle?.presupuesto || detalle?.movimiento || row || {};
    const n = safeNumber(mov?.monto_total ?? row?.monto_total ?? row?.total);
    return n > 0 ? n : items.reduce((acc, it) => acc + safeNumber(it.total), 0);
  }, [detalle, row, items]);

  const subtotal = useMemo(() => items.reduce((acc, it) => acc + safeNumber(it.subtotal), 0), [items]);
  const ivaTotal = useMemo(() => items.reduce((acc, it) => acc + safeNumber(it.iva_monto), 0), [items]);

  const tipoVentaSelected = useMemo(
    () => tiposVentaList.find((t) => String(getTipoVentaId(t) ?? "") === String(idTipoVenta)) || null,
    [tiposVentaList, idTipoVenta]
  );

  const isContado = useMemo(() => isContadoTipoVenta(tipoVentaSelected), [tipoVentaSelected]);
  const isCuentaCorriente = useMemo(() => !isContado && (tipoVentaSelected ? isCuentaCorrienteTipoVenta(tipoVentaSelected) || true : false), [isContado, tipoVentaSelected]);

  const mediosPayload = useMemo(() => buildMediosPagoPayload(mediosFilas, mediosPagoList), [mediosFilas, mediosPagoList]);
  const sumaMedios = useMemo(() => mediosPayload.reduce((acc, mp) => acc + safeNumber(mp.monto), 0), [mediosPayload]);

  const fiscalActual = useMemo(() => {
    if (fiscalArcaData?.cuit) return fiscalArcaData;
    if (clienteFiscalDb?.cuit || clienteFiscalDb?.doc_nro) return clienteFiscalDb;
    return null;
  }, [fiscalArcaData, clienteFiscalDb]);

  const ensureDefaultTipoVenta = useCallback(() => {
    const currentOk = idTipoVenta && tiposVentaList.some((t) => String(getTipoVentaId(t)) === String(idTipoVenta));
    if (currentOk) return;
    const cuenta = tiposVentaList.find(isCuentaCorrienteTipoVenta);
    const contado = tiposVentaList.find(isContadoTipoVenta);
    const selected = cuenta || contado || tiposVentaList[0] || null;
    setIdTipoVenta(selected ? String(getTipoVentaId(selected) || "") : "");
  }, [idTipoVenta, tiposVentaList]);

  const fetchClienteFiscal = useCallback(async (idCliente) => {
    if (!idCliente) {
      setClienteFiscalDb(null);
      return null;
    }
    try {
      const p = new URLSearchParams({ id_cliente: String(idCliente) });
      const data = await apiGetJson(`${API_CLIENTE_FISCAL_GET}&${p.toString()}`);
      const raw = data?.cliente_fiscal || data?.cliente || data?.data || data;
      const fiscal = normalizeClienteFiscalDb(raw || {});
      if (fiscal.cuit || fiscal.doc_nro || fiscal.razon_social) {
        setClienteFiscalDb(fiscal);
        setFiscalCuitInput(onlyDigits(fiscal.cuit || fiscal.doc_nro));
        return fiscal;
      }
      setClienteFiscalDb(null);
      return null;
    } catch {
      setClienteFiscalDb(null);
      return null;
    }
  }, []);

  const fetchDetalle = useCallback(async () => {
    if (!idPresupuesto) return;
    abortRef.current?.abort?.();
    const controller = new AbortController();
    abortRef.current = controller;
    setLoading(true);
    try {
      const data = await apiGetJson(`${API_PRESUPUESTO_GET}&id_movimiento=${encodeURIComponent(idPresupuesto)}`);
      if (controller.signal.aborted) return;
      const nextDetalle = {
        presupuesto: data?.presupuesto || data?.movimiento || row || null,
        items: Array.isArray(data?.items) ? data.items : [],
      };
      setDetalle(nextDetalle);
      setFecha(todayISO());
      const clienteId = getClienteId(nextDetalle.presupuesto) || getClienteId(row);
      fetchClienteFiscal(clienteId);
    } catch (e) {
      if (!controller.signal.aborted) showToast("error", e?.message || "No se pudo cargar el documento comercial.", 5200);
    } finally {
      if (!controller.signal.aborted) setLoading(false);
    }
  }, [idPresupuesto, row, fetchClienteFiscal, showToast]);

  useEffect(() => {
    if (!open) return undefined;
    setDetalle(null);
    setFiscalArcaData(null);
    setClienteFiscalDb(null);
    setFiscalCuitInput("");
    setMediosFilas([buildEmptyMedioPago(safeNumber(row?.monto_total || row?.total || 0))]);
    setFecha(todayISO());
    fetchDetalle();
    return () => abortRef.current?.abort?.();
  }, [open, row, fetchDetalle]);

  useEffect(() => {
    if (!open) return;
    ensureDefaultTipoVenta();
  }, [open, ensureDefaultTipoVenta]);

  useEffect(() => {
    if (!open || !isContado) return;
    setMediosFilas((prev) => {
      if (Array.isArray(prev) && prev.length) {
        return prev.map((mp, idx) => idx === 0 && safeNumber(mp.monto) <= 0 ? { ...mp, monto: total, montoDraft: formatEditableMoney(total) } : mp);
      }
      return [buildEmptyMedioPago(total)];
    });
  }, [open, isContado, total]);

  useEffect(() => {
    if (!open) return undefined;
    const onKeyDown = (event) => {
      if (event.key === "Escape" && !saving && !openResumenFactura) onClose?.();
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [open, saving, openResumenFactura, onClose]);

  const updateMedioPago = useCallback((id, patch) => {
    setMediosFilas((prev) => (Array.isArray(prev) ? prev : []).map((r) => (r.id === id ? { ...r, ...patch } : r)));
  }, []);

  const removeMedioPago = useCallback((id) => {
    setMediosFilas((prev) => {
      const arr = (Array.isArray(prev) ? prev : []).filter((r) => r.id !== id);
      return arr.length ? arr : [buildEmptyMedioPago(total)];
    });
  }, [total]);

  const addMedioPago = useCallback(() => {
    const faltante = Math.max(0, total - sumaMedios);
    setMediosFilas((prev) => [...(Array.isArray(prev) ? prev : []), buildEmptyMedioPago(faltante)]);
  }, [total, sumaMedios]);

  const fetchConfigFacturacion = useCallback(async () => {
    try {
      const data = await apiGetJson(API_CONFIG_FACTURACION);
      return data?.config || data?.config_facturacion || data?.data || data || {};
    } catch {
      return {};
    }
  }, []);

  const guardarClienteFiscal = useCallback(async (fiscal) => {
    const idCliente = clienteBase.id_cliente;
    if (!idCliente || !fiscal?.cuit) return fiscal;
    try {
      const payload = {
        id_cliente: idCliente,
        doc_tipo: 80,
        doc_nro: onlyDigits(fiscal.cuit || fiscal.doc_nro),
        cuit: onlyDigits(fiscal.cuit || fiscal.doc_nro),
        razon_social: safeStr(fiscal.razon_social),
        condicion_iva: safeStr(fiscal.condicion_iva || fiscal.cond_iva),
        domicilio: safeStr(fiscal.domicilio),
      };
      const data = await apiPostJson(API_CLIENTE_FISCAL_SAVE, payload);
      const saved = normalizeClienteFiscalDb(data?.cliente_fiscal || data?.data || payload);
      setClienteFiscalDb(saved);
      return saved;
    } catch {
      return fiscal;
    }
  }, [clienteBase.id_cliente]);

  const buscarFiscalEnArca = useCallback(async () => {
    const cuit = onlyDigits(fiscalCuitInput);
    if (cuit.length !== 11) {
      showToast("advertencia", "Ingresá un CUIT válido de 11 dígitos para facturar.", 4200);
      return null;
    }
    setFiscalLoading(true);
    try {
      const data = await apiGetJson(`${API_PADRON_CUIT}&cuit=${encodeURIComponent(cuit)}`);
      const raw = data?.data?.summary || data?.summary || data?.persona || data?.fiscal || data?.data || data?.resultado || data;
      const fiscal = normalizeArcaSummary({ ...raw, cuit });
      if (!fiscal.razon_social) fiscal.razon_social = clienteBase.nombre || "Cliente";
      setFiscalArcaData(fiscal);
      await guardarClienteFiscal(fiscal);
      showToast("exito", "Datos fiscales cargados correctamente.", 2600);
      return fiscal;
    } catch (e) {
      showToast("error", e?.message || "No se pudo consultar el CUIT.", 5200);
      return null;
    } finally {
      setFiscalLoading(false);
    }
  }, [fiscalCuitInput, clienteBase.nombre, guardarClienteFiscal, showToast]);

  const resolveFiscalParaFacturar = useCallback(async () => {
    let fiscal = fiscalArcaData || clienteFiscalDb;
    if (!fiscal?.cuit && onlyDigits(fiscalCuitInput).length === 11) {
      fiscal = await buscarFiscalEnArca();
    }
    if (!fiscal?.cuit && !fiscal?.doc_nro) {
      throw new Error("Para emitir factura real tenés que cargar el CUIT/datos fiscales del cliente.");
    }
    return buildClienteFiscalPdf(fiscal, clienteBase, clienteBase.nombre);
  }, [fiscalArcaData, clienteFiscalDb, fiscalCuitInput, buscarFiscalEnArca, clienteBase]);

  const fiscalPdfParaInterno = useCallback(() => {
    return buildClienteFiscalPdf(fiscalActual || {}, clienteBase, clienteBase.nombre);
  }, [fiscalActual, clienteBase]);

  const validate = useCallback((modo) => {
    if (convertido) return "Este documento comercial ya fue convertido en venta.";
    if (!idPresupuesto) return "No se encontró el ID del documento comercial.";
    if (!clienteBase.id_cliente) return "El documento comercial no tiene un cliente válido.";
    if (!items.length) return "El documento comercial no tiene productos o servicios cargados.";
    if (!idTipoVenta) return "Seleccioná la forma de venta.";
    if (total <= 0) return "El total del documento comercial debe ser mayor a cero.";
    if (isContado) {
      if (!mediosPayload.length) return "Para venta contado cargá al menos un medio de pago.";
      if (sumaMedios < total - 0.05) return "La suma de los medios de pago no cubre el total de la venta.";
    }
    if (modo === "facturar" && !clienteBase.id_cliente) return "Para facturar necesitás un cliente válido.";
    return "";
  }, [convertido, idPresupuesto, clienteBase.id_cliente, items.length, idTipoVenta, total, isContado, mediosPayload.length, sumaMedios]);

  const buildComprobantePayload = useCallback((cfg, fiscal, idVenta, extra = {}) => {
    const puntoVenta = Number(String(cfg?.punto_venta || "2").replace(/\D/g, "")) || 2;
    const codigoCbte = Number(String(cfg?.codigo_comprobante || "11").replace(/\D/g, "")) || 11;
    const primerMedioId = mediosPayload[0]?.id_medio_pago || null;
    const emisorPdf = normalizeConfigFacturacionPdf(cfg || {});
    const tipoVentaNombre = safeStr(tipoVentaSelected?.nombre || tipoVentaSelected?.descripcion || tipoVentaSelected?.detalle || (isContado ? "Contado" : "Cuenta corriente"));

    return {
      id_pago: null,
      id_sistema: null,
      labelCliente: fiscal?.razon_social || clienteBase.nombre || "Cliente",
      labelSistema: "Venta desde documento comercial",
      cliente_facturacion: fiscal || fiscalPdfParaInterno(),
      config_facturacion: cfg || {},
      ...emisorPdf,
      id_cliente: clienteBase.id_cliente || null,
      id_tipo_venta: Number(idTipoVenta || 0) || null,
      tipo_venta_nombre: tipoVentaNombre,
      id_medio_pago: isContado ? primerMedioId : null,
      id_clasificacion: null,
      fecha_cbte_iso: String(fecha || todayISO()).slice(0, 10),
      vto_pago_iso: plusDaysISOFrom(fecha || todayISO(), 10),
      cbte_tipo: extra.cbte_tipo ?? codigoCbte,
      pto_vta: extra.pto_vta ?? puntoVenta,
      items_facturacion: items,
      medios_pago: isContado ? mediosPayload : [],
      total_ars: total,
      monto: total,
      importe: total,
      ids_movimiento: idVenta ? [Number(idVenta)] : [],
      id_presupuesto_origen: idPresupuesto,
      observaciones: extra.observaciones || "",
      emisor: emisorPdf.emisor,
      ...extra,
    };
  }, [mediosPayload, tipoVentaSelected, isContado, clienteBase, idTipoVenta, fecha, items, total, idPresupuesto, fiscalPdfParaInterno]);

  const subirPdfDocumento = useCallback(async ({ tipo, idMovimiento, blob, filename, meta, emitidoEnArca = false, factura = null }) => {
    if (!idMovimiento || !blob) throw new Error(`No se pudo generar o subir ${String(tipo || "comprobante").toLowerCase()}.`);
    const fd = new FormData();
    fd.append("tipo", tipo);
    fd.append("id_movimiento", String(idMovimiento));
    if (Array.isArray(meta?.ids_movimiento) && meta.ids_movimiento.length) {
      fd.append("ids_movimiento", JSON.stringify(meta.ids_movimiento));
    }
    fd.append("pdf", blob instanceof Blob ? blob : new Blob([blob], { type: "application/pdf" }), filename || `${String(tipo || "comprobante").toLowerCase()}.pdf`);
    fd.append("meta", JSON.stringify({
      tipo,
      estado: emitidoEnArca ? "emitida" : String(tipo || "").toLowerCase(),
      emitido_en_arca: emitidoEnArca ? 1 : 0,
      id_pago: meta?.id_pago ?? null,
      id_sistema: meta?.id_sistema ?? null,
      id_cliente: meta?.id_cliente ?? clienteBase.id_cliente ?? null,
      ids_movimiento: Array.isArray(meta?.ids_movimiento) ? meta.ids_movimiento : [],
      monto_ars: Number(meta?.total_ars ?? meta?.importe ?? total ?? 0),
      fecha_cbte: meta?.fecha_cbte_iso ?? null,
      razon_social: meta?.cliente_facturacion?.razon_social || meta?.labelCliente || null,
      cond_iva: meta?.cliente_facturacion?.cond_iva || meta?.cliente_facturacion?.condicion_iva || null,
      domicilio: meta?.cliente_facturacion?.domicilio || null,
      cliente_facturacion: meta?.cliente_facturacion || null,
      emisor: meta?.emisor || null,
      config_facturacion: meta?.config_facturacion || null,
      resultado: emitidoEnArca ? "A" : "P",
      cae: factura?.cae ?? null,
      cae_vto: factura?.cae_vto ?? null,
      cbte_tipo: meta?.cbte_tipo ?? factura?.cbte_tipo ?? null,
      pto_vta: meta?.pto_vta ?? factura?.pto_vta ?? null,
      cbte_nro: factura?.cbte_nro ?? factura?.numero ?? null,
      json_arca: factura?.json_arca || factura?.raw_min || factura || null,
      resumen_facturacion: {
        ...meta,
        tipo,
        emitido_en_arca: emitidoEnArca ? 1 : 0,
        items_facturacion: Array.isArray(meta?.items_facturacion) ? meta.items_facturacion : [],
      },
    }));

    const data = await fetch(API_VINCULAR_COMPROBANTE, {
      method: "POST",
      headers: buildFormHeaders(),
      body: fd,
    }).then(parseJsonOrThrow);
    return data;
  }, [clienteBase.id_cliente, total]);

  const subirArchivosChequesCreados = useCallback(async (info) => {
    const creados = Array.isArray(info?.cheques_creados) ? info.cheques_creados : [];
    if (!creados.length) return;

    await Promise.all(creados.map(async (ch) => {
      const uid = String(ch?.frontend_row_uid || "");
      const idCheque = Number(ch?.id_cheque || 0);
      const file = getChequeFileFromRows(mediosFilas, uid);
      if (!idCheque || !file) return;

      const fd = new FormData();
      fd.append("id_cheque", String(idCheque));
      fd.append("archivo", file, file.name || "cheque.pdf");
      await fetch(API_CHEQUES_ACTUALIZAR, {
        method: "POST",
        headers: buildFormHeaders(),
        body: fd,
      }).then(parseJsonOrThrow);
    }));
  }, [mediosFilas]);

  const guardarConversion = useCallback(async ({ modo, fiscal = null }) => {
    const payload = {
      id_presupuesto: idPresupuesto,
      fecha,
      id_tipo_venta: Number(idTipoVenta || 0) || null,
      id_medio_pago: isContado ? (mediosPayload[0]?.id_medio_pago || null) : null,
      medios_pago: isContado ? mediosPayload : [],
      id_usuario: getIdUsuarioLocal(),
      accion_venta: modo,
      es_facturada: modo === "facturar" ? 1 : 0,
      cliente_fiscal: fiscal || null,
    };

    return await apiPostJson(API_CONVERTIR, payload);
  }, [idPresupuesto, fecha, idTipoVenta, isContado, mediosPayload]);

  const afterSaved = useCallback(async (data, mensaje) => {
    showToast("exito", mensaje, 4600);
    await Promise.resolve(onSaved?.(data));
    onClose?.();
  }, [onSaved, onClose, showToast]);

  const guardarComoVenta = useCallback(async () => {
    const error = validate("guardar");
    if (error) return showToast("advertencia", error, 5200);

    setSaving(true);
    try {
      const [cfg] = await Promise.all([fetchConfigFacturacion()]);
      const fiscal = fiscalPdfParaInterno();
      const data = await guardarConversion({ modo: "guardar", fiscal });
      const idVenta = Number(data?.id_movimiento || data?.id_venta || data?.ids?.[0] || data?.ids_movimiento?.[0] || 0);
      if (!idVenta) throw new Error("La venta se creó, pero no se recibió su ID para vincular comprobantes.");

      const ventaMeta = buildComprobantePayload(cfg, fiscal, idVenta, {
        cbte_tipo: null,
        pto_vta: null,
        observaciones: "Comprobante interno generado desde un documento comercial. Sin CAE, sin QR fiscal y sin validez fiscal.",
      });

      const ventaPdf = await saveVentaNoFacturadaPdf({ data: ventaMeta, download: false });
      await subirPdfDocumento({
        tipo: "VENTA_NO_FACTURADA",
        idMovimiento: idVenta,
        blob: ventaPdf?.blob,
        filename: ventaPdf?.filename,
        meta: ventaMeta,
      });

      const remitoMeta = {
        ...ventaMeta,
        tipo: "REMITO",
        estado: "remito",
        observaciones_remito: "Remito generado automáticamente desde un documento comercial convertido en venta.",
      };
      const remitoPdf = await saveRemitoPdf({ data: remitoMeta, download: false });
      await subirPdfDocumento({
        tipo: "REMITO",
        idMovimiento: idVenta,
        blob: remitoPdf?.blob,
        filename: remitoPdf?.filename,
        meta: remitoMeta,
      });

      await subirArchivosChequesCreados(data);
      await afterSaved(data, "Documento comercial guardado como venta. Se generaron la factura no emitida y el remito.");
    } catch (e) {
      showToast("error", e?.message || "No se pudo guardar como venta.", 6500);
    } finally {
      setSaving(false);
    }
  }, [validate, showToast, fetchConfigFacturacion, fiscalPdfParaInterno, guardarConversion, buildComprobantePayload, subirPdfDocumento, subirArchivosChequesCreados, afterSaved]);

  const abrirFacturacion = useCallback(async () => {
    const error = validate("facturar");
    if (error) return showToast("advertencia", error, 5200);

    setSaving(true);
    try {
      const [cfg, fiscal] = await Promise.all([fetchConfigFacturacion(), resolveFiscalParaFacturar()]);
      const data = buildComprobantePayload(cfg, fiscal, null, {
        observaciones: "Factura emitida desde documento comercial convertido en venta.",
      });
      setFiscalParaFacturar(fiscal);
      setResumenFacturaData(data);
      setOpenResumenFactura(true);
    } catch (e) {
      showToast("error", e?.message || "No se pudo preparar la facturación.", 6200);
    } finally {
      setSaving(false);
    }
  }, [validate, showToast, fetchConfigFacturacion, resolveFiscalParaFacturar, buildComprobantePayload]);

  const finalizarFacturacionYGuardarVenta = useCallback(async (factEmitida) => {
    setSaving(true);
    try {
      const data = await guardarConversion({ modo: "facturar", fiscal: fiscalParaFacturar || resumenFacturaData?.cliente_facturacion || null });
      const idVenta = Number(data?.id_movimiento || data?.id_venta || data?.ids?.[0] || data?.ids_movimiento?.[0] || 0);
      if (!idVenta) throw new Error("La factura se emitió, pero no se recibió el ID de venta para guardar los documentos.");

      const facturaMeta = {
        ...(resumenFacturaData || {}),
        ids_movimiento: [idVenta],
        id_movimiento: idVenta,
        emitido_en_arca: 1,
        cae: factEmitida?.cae ?? null,
        cae_vto: factEmitida?.cae_vto ?? null,
        cbte_nro: factEmitida?.cbte_nro ?? factEmitida?.numero ?? null,
      };

      if (factEmitida?.pdf_blob) {
        await subirPdfDocumento({
          tipo: "FACTURA",
          idMovimiento: idVenta,
          blob: factEmitida.pdf_blob,
          filename: factEmitida.pdf_filename || "factura.pdf",
          meta: facturaMeta,
          emitidoEnArca: true,
          factura: factEmitida,
        });
      }

      const remitoMeta = {
        ...facturaMeta,
        tipo: "REMITO",
        estado: "remito",
        observaciones_remito: "Remito generado automáticamente desde una factura real emitida en ARCA.",
      };
      const remitoPdf = await saveRemitoPdf({ data: remitoMeta, download: false });
      await subirPdfDocumento({
        tipo: "REMITO",
        idMovimiento: idVenta,
        blob: remitoPdf?.blob,
        filename: remitoPdf?.filename,
        meta: remitoMeta,
      });

      await subirArchivosChequesCreados(data);
      setOpenResumenFactura(false);
      await afterSaved(data, "Documento comercial facturado correctamente. Se guardaron la factura emitida y el remito.");
    } catch (e) {
      showToast("error", e?.message || "La factura se emitió, pero no se pudo terminar de guardar la venta.", 7000);
    } finally {
      setSaving(false);
    }
  }, [guardarConversion, fiscalParaFacturar, resumenFacturaData, subirPdfDocumento, subirArchivosChequesCreados, afterSaved, showToast]);

  if (!open) return null;

  const handleBackdrop = (event) => {
    if (event.target === event.currentTarget && !saving && !openResumenFactura) onClose?.();
  };

  const modal = (
    <>
      <div className="mi-modal__overlay dc-asignar-overlay" onMouseDown={handleBackdrop}>
        <div
          className="mi-modal__container mi-modal__container--mov dc-asignar-modal"
          role="dialog"
          aria-modal="true"
          onMouseDown={(e) => e.stopPropagation()}
        >
          <div className="mi-modal__header">
            <div className="mi-modal__head-icon" aria-hidden="true">
              <FontAwesomeIcon icon={faFileInvoiceDollar} />
            </div>
            <div className="mi-modal__head-left">
              <h2 className="mi-modal__title">Asignar como venta</h2>
              <p className="dc-asignar-head-subtitle">
                Convertí el documento comercial en una venta respetando cliente, detalle y productos.
              </p>
            </div>
            <button type="button" className="mi-modal__close" onClick={onClose} disabled={saving} aria-label="Cerrar">
              ✕
            </button>
          </div>

          {convertido ? (
            <div className="dc-asignar-convertido">
              <FontAwesomeIcon icon={faCheckCircle} />
              <div>
                <b>Este documento comercial ya fue convertido en venta.</b>
                <span>No se vuelve a crear otra venta para evitar duplicados.</span>
              </div>
            </div>
          ) : null}

          <div className="mi-modal__content dc-asignar-content">
            {loading ? (
              <div className="dc-asignar-loading">
                <FontAwesomeIcon icon={faSpinner} spin /> Cargando datos del documento comercial…
              </div>
            ) : (
              <div className="mi-cr-grid dc-asignar-grid">
                <section className="mi-cr-table dc-asignar-products">
                  <div className="mi-cr-table__head dc-asignar-products__head">
                    <div style={{ paddingLeft: 10 }}>Detalle</div>
                    <div>Cant.</div>
                    <div className="right">Precio</div>
                    <div>IVA %</div>
                    <div className="right">Total</div>
                  </div>

                  <div className="mi-cr-table__rows dc-asignar-products__rows">
                    {items.map((it) => (
                      <div key={it.id} className="mi-cr-row dc-asignar-product-row">
                        <div className="mi-cr-cell mi-cr-cell--detalle">
                          <b className="mdm-product-name">{safeText(it.descripcion)}</b>
                          {it.codigo ? <small>Código: {it.codigo}</small> : null}
                        </div>
                        <div className="mi-cr-cell mi-cr-cell--center mi-cr-cell--soft">{safeNumber(it.cantidad).toLocaleString("es-AR")}</div>
                        <div className="mi-cr-cell mi-cr-cell--right mi-cr-cell--mono mi-cr-cell--soft">{moneyARS(it.precio)}</div>
                        <div className="mi-cr-cell mi-cr-cell--center mi-cr-cell--soft">{safeNumber(it.iva_pct).toLocaleString("es-AR")}%</div>
                        <div className="mi-cr-cell mi-cr-cell--right mi-cr-cell--mono mi-cr-cell--total-val">{moneyARS(it.total)}</div>
                      </div>
                    ))}
                    {!items.length ? (
                      <div className="dc-asignar-empty">No hay productos cargados.</div>
                    ) : null}
                  </div>

                  <div className="mi-cr-table__foot dc-asignar-products__foot">
                    <div className="mi-cr-foot-actions">
                      <div className="dc-asignar-doc-chip">
                        <span>Documento</span>
                        <b>N° {idPresupuesto || "—"}</b>
                      </div>
                      <div className="nv-foot-sep" />
                    </div>
                    <div className="mi-cr-totals">
                      <div className="mi-cr-totalLine mi-cr-totalLine--sub">
                        <span>Subtotal</span>
                        <b>{moneyARS(subtotal)}</b>
                      </div>
                      <div className="mi-cr-totalLine mi-cr-totalLine--iva">
                        <span>IVA</span>
                        <b>{moneyARS(ivaTotal)}</b>
                      </div>
                      <div className="mi-cr-totalLine mi-cr-totalLine--total">
                        <span>Total</span>
                        <b>{moneyARS(total)}</b>
                      </div>
                    </div>
                  </div>
                </section>

                <div className="mi-cr-filters dc-asignar-side">
                  <aside className="nc-aside">
                    <div className="nc-section">
                      <div className="nc-section-head">
                        <div className="nc-section-dot" />
                        <span>Datos de venta</span>
                      </div>

                      <div className="nc-section-body">
                        <div
                          className="nc-field dc-asignar-date-field"
                          onClick={() => {
                            if (!saving) document.getElementById("dc-asignar-fecha")?.showPicker?.();
                          }}
                        >
                          <input
                            id="dc-asignar-fecha"
                            className="nc-input"
                            type="date"
                            placeholder=" "
                            value={fecha}
                            onChange={(e) => setFecha(e.target.value)}
                            disabled={saving}
                          />
                          <label className="nc-label">Fecha</label>
                        </div>

                        <div className="nc-field dc-asignar-readonly-field">
                          <select
                            className="nc-input nc-select"
                            value="cliente-presupuesto"
                            disabled
                            title="El cliente viene del presupuesto seleccionado y no se puede cambiar."
                          >
                            <option value="cliente-presupuesto">
                              {safeText(clienteBase.nombre || clienteBase.razon_social)}
                            </option>
                          </select>
                          <label className="nc-label nc-label--up">Cliente *</label>
                        </div>

                        <div className="nc-field">
                          <select
                            className="nc-input nc-select"
                            value={idTipoVenta}
                            onChange={(e) => setIdTipoVenta(e.target.value)}
                            disabled={saving}
                          >
                            <option value="">Seleccionar</option>
                            {tiposVentaList.map((t) => {
                              const id = getTipoVentaId(t);
                              return <option key={id || safeStr(t.nombre)} value={id || ""}>{safeText(t.nombre || t.descripcion || t.detalle)}</option>;
                            })}
                          </select>
                          <label className={`nc-label${idTipoVenta ? " nc-label--up" : ""}`}>Forma de venta *</label>
                        </div>

                        {isCuentaCorriente ? (
                          <div className="nc-cc-info">
                            Quedará registrada como <b>pendiente de cobro</b> en la cuenta corriente del cliente.
                          </div>
                        ) : null}

                        {isContado ? (
                          <PanelMediosPagoInlineVenta
                            mediosFilas={mediosFilas}
                            mediosPagoList={mediosPagoList}
                            totalCompra={total}
                            onUpdate={updateMedioPago}
                            onRemove={removeMedioPago}
                            onAdd={addMedioPago}
                            showToast={showToast}
                            saving={saving}
                          />
                        ) : null}
                      </div>
                    </div>

                    <div className="nc-section">
                      <div className="nc-section-head">
                        <div className="nc-section-dot" />
                        <span>Datos fiscales para emitir factura</span>
                      </div>

                      <div className="nc-section-body">
                        <div className="nc-field">
                          <input
                            className="nc-input"
                            value={fiscalCuitInput}
                            maxLength={11}
                            onChange={(e) => setFiscalCuitInput(onlyDigits(e.target.value).slice(0, 11))}
                            placeholder=" "
                            disabled={saving || fiscalLoading}
                            inputMode="numeric"
                          />
                          <label className={`nc-label${fiscalCuitInput ? " nc-label--up" : ""}`}>CUIT del cliente</label>
                        </div>

                        <button type="button" className="mit-btn mit-btn--ghost mit-btn--block dc-asignar-search-btn" onClick={buscarFiscalEnArca} disabled={saving || fiscalLoading}>
                          {fiscalLoading ? <FontAwesomeIcon icon={faSpinner} spin /> : <FontAwesomeIcon icon={faFileInvoiceDollar} />}
                          Buscar datos fiscales
                        </button>

                        {fiscalActual?.razon_social || fiscalActual?.cuit ? (
                          <div className="arca-alert arca-alert--info dc-asignar-fiscal-ok">
                            <div className="arca-alert__title">Datos encontrados</div>
                            <div className="arca-resumen">
                              <div className="arca-row arca-row--full">
                                <b>Razón social:</b>
                                <span>{safeText(fiscalActual?.razon_social)}</span>
                              </div>
                              <div className="arca-row">
                                <b>CUIT:</b>
                                <span>{safeText(fiscalActual?.cuit || fiscalActual?.doc_nro)}</span>
                              </div>
                              <div className="arca-row">
                                <b>IVA:</b>
                                <span>{safeText(fiscalActual?.condicion_iva || fiscalActual?.cond_iva)}</span>
                              </div>
                            </div>
                          </div>
                        ) : (
                          <div className="arca-alert arca-alert--error dc-asignar-alert">
                            <FontAwesomeIcon icon={faTriangleExclamation} />
                            <span>Para “Facturar en ARCA” el cliente necesita CUIT y datos fiscales.</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </aside>

                  <div className="nc-actions mi-cr-filters__actions mi-cr-filters__actions--sticky dc-asignar-actions">
                    <button type="button" className="mit-btn mit-btn--solid mit-btn--block" onClick={guardarComoVenta} disabled={saving || loading || convertido}>
                      {saving ? <FontAwesomeIcon icon={faSpinner} spin /> : <FontAwesomeIcon icon={faFloppyDisk} />}
                      Guardar
                    </button>
                    <button type="button" className="mit-btn mit-btn--ghost mit-btn--block" onClick={abrirFacturacion} disabled={saving || loading || convertido}>
                      {saving ? <FontAwesomeIcon icon={faSpinner} spin /> : <FontAwesomeIcon icon={faFileInvoiceDollar} />}
                      Facturar en ARCA
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <ModalFacturaBaltoResumen
        open={openResumenFactura}
        onClose={() => setOpenResumenFactura(false)}
        onBack={() => setOpenResumenFactura(false)}
        onCloseAll={() => setOpenResumenFactura(false)}
        apiBase={API}
        action="ventas"
        data={resumenFacturaData}
        docTipo={Number(resumenFacturaData?.cliente_facturacion?.doc_tipo || 80)}
        docNro={String(resumenFacturaData?.cliente_facturacion?.doc_nro || resumenFacturaData?.cliente_facturacion?.cuit || "")}
        cbteTipo={Number(resumenFacturaData?.cbte_tipo || 11)}
        ptoVta={String(resumenFacturaData?.pto_vta || 2)}
        onDone={finalizarFacturacionYGuardarVenta}
        skipMovimientoAutocreacion
      />
    </>
  );

  return createPortal(modal, document.body);
}
